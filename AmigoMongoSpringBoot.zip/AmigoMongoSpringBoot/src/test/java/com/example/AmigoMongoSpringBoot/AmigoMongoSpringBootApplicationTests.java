package com.example.AmigoMongoSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class AmigoMongoSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
