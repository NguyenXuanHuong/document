#### Links for the GitHub Actions video

List of GitHub Actions:
* https://github.com/actions
* https://github.com/marketplace?type=actions

Events:
* https://docs.github.com/en/free-pro-team@latest/actions/reference/events-that-trigger-workflows

Docker action we use in the tutorial:
* https://github.com/marketplace/actions/docker-build-push
