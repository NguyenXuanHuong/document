package xing.rujuan.aop.advices;

public interface AccountService {

    void deposit(double amount);
}
