package xing.rujuan.aop.proxy;

public class CustomerService {

    public void doSomething(){

        System.out.println("Do something in CustomerService...");
    }
}
