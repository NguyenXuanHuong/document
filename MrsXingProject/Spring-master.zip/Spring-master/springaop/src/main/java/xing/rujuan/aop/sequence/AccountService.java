package xing.rujuan.aop.sequence;

public interface AccountService {

    void deposit(double amount);
}
