package xing.rujuan.aop.terms;

public interface CustomerService {

    void doSomething();
}
