package xing.rujuan.aop.xml;

public interface CustomerService {

    void doSomething();
}
