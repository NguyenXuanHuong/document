package xing.rujuan.autowired;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan("xing.rujuan.autowired")
public class AppConfig {
}
