package xing.rujuan.autowired;

public interface CustomerDao {
}
