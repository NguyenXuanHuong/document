package xing.rujuan.autowired;

import org.springframework.stereotype.Repository;

@Repository("custDao")
public class CustomerDaoImpl implements CustomerDao {
}
