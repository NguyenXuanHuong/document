package xing.rujuan.autowired;

import org.springframework.stereotype.Repository;

@Repository
public class CustomerDaoImpl2 implements CustomerDao {
}
