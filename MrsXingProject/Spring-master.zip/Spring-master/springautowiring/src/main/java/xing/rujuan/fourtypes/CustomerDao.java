package xing.rujuan.fourtypes;

public class CustomerDao {
}
