package xing.rujuan;

import org.springframework.stereotype.Component;

@Component
public class Address {
}
