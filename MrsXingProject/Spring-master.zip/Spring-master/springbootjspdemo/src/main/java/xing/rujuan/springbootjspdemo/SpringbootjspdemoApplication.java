package xing.rujuan.springbootjspdemo;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringbootjspdemoApplication {

    public static void main(String[] args) {
        SpringApplication.run(SpringbootjspdemoApplication.class, args);
    }

}
