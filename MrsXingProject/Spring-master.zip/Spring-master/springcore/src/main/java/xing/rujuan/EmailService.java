package xing.rujuan;

public class EmailService {

    public void sendEmail(String receiver, String message) {
        //provide actual logic
        System.out.println(message + " is being sent to " + receiver);
    }
}
