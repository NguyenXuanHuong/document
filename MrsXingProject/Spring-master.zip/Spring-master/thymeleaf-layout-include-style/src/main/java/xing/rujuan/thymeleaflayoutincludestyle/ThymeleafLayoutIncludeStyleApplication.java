package xing.rujuan.thymeleaflayoutincludestyle;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymeleafLayoutIncludeStyleApplication {

    public static void main(String[] args) {
        SpringApplication.run(ThymeleafLayoutIncludeStyleApplication.class, args);
    }

}
