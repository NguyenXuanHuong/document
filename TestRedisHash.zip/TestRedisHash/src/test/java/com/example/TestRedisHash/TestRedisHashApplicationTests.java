package com.example.TestRedisHash;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestRedisHashApplicationTests {

	@Test
	void contextLoads() {
	}

}
