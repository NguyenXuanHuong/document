package com.example.TestSQLQuery;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestSqlQueryApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestSqlQueryApplication.class, args);
	}

}
