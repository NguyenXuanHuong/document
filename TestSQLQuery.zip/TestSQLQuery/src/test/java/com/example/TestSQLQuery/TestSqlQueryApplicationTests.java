package com.example.TestSQLQuery;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestSqlQueryApplicationTests {

	@Test
	void contextLoads() {
	}

}
