package com.example.ThymeleafMrsXing;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ThymeleafMrsXingApplication {

	public static void main(String[] args) {
		SpringApplication.run(ThymeleafMrsXingApplication.class, args);
	}

}
