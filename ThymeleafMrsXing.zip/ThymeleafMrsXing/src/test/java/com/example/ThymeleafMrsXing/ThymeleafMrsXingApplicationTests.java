package com.example.ThymeleafMrsXing;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ThymeleafMrsXingApplicationTests {

	@Test
	void contextLoads() {
	}

}
