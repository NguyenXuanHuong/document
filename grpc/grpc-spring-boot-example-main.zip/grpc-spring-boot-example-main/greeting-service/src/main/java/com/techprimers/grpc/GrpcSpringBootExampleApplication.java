package com.techprimers.grpc;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class GrpcSpringBootExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(GrpcSpringBootExampleApplication.class, args);
	}

}
