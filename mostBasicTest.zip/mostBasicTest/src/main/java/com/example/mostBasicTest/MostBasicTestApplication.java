package com.example.mostBasicTest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MostBasicTestApplication {

	public static void main(String[] args) {
		SpringApplication.run(MostBasicTestApplication.class, args);
	}

}
