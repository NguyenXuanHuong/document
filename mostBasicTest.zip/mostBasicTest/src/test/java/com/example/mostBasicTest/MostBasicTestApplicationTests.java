package com.example.mostBasicTest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MostBasicTestApplicationTests {

	@Test
	void contextLoads() {
	}

}
