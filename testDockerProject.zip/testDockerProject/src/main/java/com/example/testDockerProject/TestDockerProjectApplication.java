package com.example.testDockerProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestDockerProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestDockerProjectApplication.class, args);
	}

}
