package com.example.testHttpServletRequest;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestHttpServletRequestApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestHttpServletRequestApplication.class, args);
	}

}
