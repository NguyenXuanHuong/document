package com.example.clientTestHttps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ClientTestHttpsApplicationTests {

	@Test
	void contextLoads() {
	}

}
