package com.example.serverTestHttps;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ServerTestHttpsApplicationTests {

	@Test
	void contextLoads() {
	}

}
