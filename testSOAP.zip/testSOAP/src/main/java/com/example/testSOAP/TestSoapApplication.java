package com.example.testSOAP;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestSoapApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestSoapApplication.class, args);
	}

}
