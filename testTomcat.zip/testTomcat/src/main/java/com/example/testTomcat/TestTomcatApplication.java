package com.example.testTomcat;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class TestTomcatApplication {

	public static void main(String[] args) {
		SpringApplication.run(TestTomcatApplication.class, args);
	}

}
