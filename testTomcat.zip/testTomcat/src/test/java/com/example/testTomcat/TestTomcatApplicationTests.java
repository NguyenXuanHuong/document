package com.example.testTomcat;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class TestTomcatApplicationTests {

	@Test
	void contextLoads() {
	}

}
